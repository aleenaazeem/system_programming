#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

//append.c

main()
{

//Appends buff1 at the end of test9.txt

int fd3=open("test9.txt",O_APPEND|O_RDWR);
printf("\n The value of fd3 is %d\n",fd3);

char buff[5];
for(int i=0;i<=3;i++){
read(fd3,buff,5);
printf("%s\n",buff);
} 


int n=write(fd3,"COMP 8567 ",10);
lseek(fd3,0,SEEK_SET); 
n=write(fd3,"COMP 8567 ",10);
lseek(fd3,0,SEEK_SET);  
n=write(fd3,"COMP 8567 ",10);
lseek(fd3,0,SEEK_SET);  
n=write(fd3,"COMP 8567 ",10); 
if(n<0)
printf("\nWrite unsuccessful\n");
else
printf("\nWrite successful\n");


close(fd3);

}
