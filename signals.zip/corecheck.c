#include <stdio.h> 
#include <stdlib.h> 

int main(void){ 
int a=10,b=100;
b=b/0; 
} 
