#include <stdio.h> 
#include <stdlib.h> 
#include <stdarg.h>

double total(int,...);

int main(int argc, char *argv[]){ 
printf("total of 10 and 20 is %d \n", total(2, 10, 20));
//printf("total of 10, 20 and 30 is  lf\n",total(3, 10, 20, 30));
//printf("total of 10, 20, 30 and 40 is  lf\n", total(4, 10, 20, 30, 40));
//printf("total of 10, 20, 30, 40 and 50 is  lf\n",total(5, 10, 20, 30, 40, 50));
exit(0);
}


double total(int n,...) { 

va_list  argList; int sum;
int i, v;
printf("\nTHe number of arguments is %d\n",n);

// create argList for the n arguments va_start(argList, n);

// extract all arguments from argList 

for (i = 0; i < n; i++) {
v=va_arg(argList, int);
printf("\n%d",v);
sum += v;
}
va_end(argList); 
return(sum);

}


