

#include <stdio.h>


int main(void) {

int num=100;

float fnum=200.0;

int *ptr1=&fnum;
float *ptr2=&fnum;
/*
printf("\nThe value of *b is: %d\n",*b);
printf("\nThe value of **c is: %d\n",**c);
printf("\nThe value of ***d is: %d\n",***d);
*/

}

